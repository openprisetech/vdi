// Listen for messages from the popup
chrome.runtime.onMessage.addListener(function (msg, sender,sendResponse) {
  if (msg.from === 'sidebar') {
    displayIFrame();
  }  
});

document.addEventListener("click", function(event){
  // If user clicked on an HTML element (following HTML elements)
  if(event.target && event.target.type && ["TEXT","URL","EMAIL","TEL","DATE","TIME","SELECT-ONE","RADIO","CHECKBOX","TEXTAREA"].indexOf(event.target.type.toUpperCase()) > -1) {
    let targetId, targetLabel;
    if(window.location.hostname.includes('salesforce.com')) {
      targetLabel = $('label[for="'+event.target.id+'"]').clone().children().remove().end().text();
      targetId = event.target.id;
    }
    else if(window.location.hostname.includes('lightning.force.com')) {
      targetLabel = $(event.target).closest('div').find('label').find('span')[0].innerText;
      targetId = targetLabel;
    }
    chrome.runtime.sendMessage({type: "DOMInfo", formField: true, hostname:window.location.hostname, targetId: targetId, targetValue: event.target.value, targetLabel: targetLabel}, function(response) {
      return true;
    });
  }
  // If user selects certain content in the document other than form elements
  else {
    if($(event.target)) {
      try {
        let targetLabel, targetId;
        if(window.location.hostname.includes('salesforce.com')) {
          targetLabel = $(event.target).closest("td").prev()[0].innerText;
          targetId = event.target.id;
        }
        else if(window.location.hostname.includes('lightning.force.com')) {
          targetLabel = $(event.target).closest("div").prev()[0].innerText;
          targetId = targetLabel;
        }
        chrome.runtime.sendMessage({type: "DOMInfo", formField: false, hostname:window.location.hostname, targetId: targetId, targetValue: event.target.innerText, targetLabel: targetLabel}, function(response) {});
      } catch(error) {}
    }
  }  
});

function displayIFrame() {
var iframe = document.createElement('iframe');
iframe.style.height = "100%";
iframe.style.width = "460px";
iframe.style.minwidth = "460px";
iframe.style.position = "fixed";
iframe.style.top = "10px";
iframe.style.right = "0px";
iframe.style.zIndex = "999999";
iframe.frameBorder = "none"; 
iframe.id = "opextiframe";
iframe.src = chrome.extension.getURL("popup.html");
document.body.appendChild(iframe);
}