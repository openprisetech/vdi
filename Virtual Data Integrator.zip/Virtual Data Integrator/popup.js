// Vue.use(VeeValidate);
Vue.use(window.vuelidate.default);
const { required } = window.validators

Vue.component('editable', {
  template: `<div contenteditable="true" @input="$emit('update:content', $event.target.innerText)"></div>`,
  props: ['content'],
  mounted: function () {
      this.$el.innerText = this.content;
  }

});

var vueObj = new Vue({
  el: '#popupTest',
  data: {
      apikey: '',
      pipeline: '',
      template: '',
      templates: [],
      panel: '',
      panels: [],
      templatePanels: [],
      configPanels:[{name:'',id:''}],
      displayName: '',
      inputFields: [],
      outputFields: [],
      outputTableConfig: [],
      inputMapping: [{key: '', value: ''}],
      outputMapping: [{key: '', value: ''}],
      inputBindings: {},
      outputBindings: {},
      loading: false,
      executing: false ,
      isErrorAPIKey: false,
      errorMessage: '',
      apiEnabledPipelines: [],
      flag: null,
      outputResponse: null,
      outputColumns: [],
      tabName: 'ConfigPanel',
      collapsiblePanels: [],
      url: 'https://api.openprisecloud.com',
      checkAll:false,
      run:false,
      order:'desc',
      curColumn:'',
      sortDirection:false,
      toggle:false,
      panelCounter: 0,
      rules: {
        'required': value => !!value || 'Required.',
        'range': value => (!!(value>=75 && value<=250)) || 'Value must be between 75 and 250.',
      },
      panelExpansion:[true],
      stepSize:75,
      toggleSize:45,
      templateRun:'',
      dialog: { editTempDialog:'', saveTempDialog:'', panelDialog:'', editPanelDialog:'', deleteDialog:'' },
      dialogTextField: { editTemplate:'', newTemplate:'', newPanel : '', editPanel:'' },
      form: { editPanel:true, newPanel:true, newTemplate:true, editTemplate:true, templateValid: true, panelValid:true },
      setTemplate: false,
      loadingFields:'',
      errorAPI:'', //If API key doesn't match with environment
      alert: {'status': false, 'message': '', 'timeout': 10000},
      deleteTempPanel: {panelStatus: false, message: '', tempStatus:false},
      accessType: {panel:'Private', template: 'Private'},
      accessTypes: ['Private', 'Public'],
      isAdmin: {panel: false, template: false},
      temp: {footerText: '', isValidAPIKey: '', apiKey: {role: '', isAPIUser: ''}}, // isValidAPIKey is to set error messages for invalid API key
    },
    watch: {
      // whenever all the API calls completed, this function will run
      panelCounter: function (counter) {
        if(counter == 0)
          this.replaceDOMData();
      }
    },
  mounted: function() {
    if(localStorage.getItem('apikey')) {
      this.apikey = localStorage.getItem('apikey');
    }
    else{
      this.tabName='Settings';
    }
    if(localStorage.getItem('stepSize')) {
      this.stepSize=localStorage.getItem('stepSize');
    }
    if(localStorage.getItem('websiteurl')) {
      this.url=localStorage.getItem('websiteurl');
    }
    else{
      localStorage.setItem('websiteurl', this.url);
    }
    if(localStorage.getItem('defaultTemplate')) {
      this.templateRun = parseInt(localStorage.getItem('defaultTemplate'))
    }

    //To set up the Popup window size
    $(document).ready(function() {
      windowHeight = parseInt($(window).height())-160;
        $('.tabs').css('min-height', windowHeight);
        $('.tabs').css('max-height', windowHeight);
        iframeHeight=parseInt($(window).height())-30;
        chrome.tabs.executeScript({
          code:"$('#opextiframe').height("+iframeHeight+");"
          }, (results) => {
        });
    });
    this.getFooterContent();
    this.getKeyPermission();
  },
  computed:{
    //To get output fields
    getServiceOutputFields: function() {
      let arr = [];
      _.map(_.keys(this.outputFields), function(item) {
        let obj = {};
        obj.key = item;
        obj.value = "";
        arr.push(obj);
      });
      return arr;
    },
    //To get input fields
    getServiceInputFields: function() {
      let arr = [];
      _.map(_.keys(this.inputFields), function(item) {
        let obj = {};
        obj.key = item;
        obj.value = "";
        arr.push(obj);
      });
      return arr;
    },
    //To filter templates
    filteredTemplates: function() {
      return this.templates.filter(function(item) {
        return item.id;
      });
    },
     //To filter panels
    filteredPanels: function() {
      return this.panels.filter(function(item) {
        return item.id;
      });
    }
  },
  methods: {
    // Get extension version
    getExtensionVersion: function() {
      let manifestData = chrome.runtime.getManifest();
      return manifestData.version;
    },
    //Footer API
    getFooterContent: function () {
      var url = localStorage.getItem('websiteurl') + "/daass/configuration/getExtensionMetaData"
      this.$http.get(url).then(response => {
        // If success
        this.temp.footerText = response.data.footerText
      }, error => {
        this.alert.status = true
        this.alert.message = "Unexpected error. Please contact Openprise"
        this.alert.color = "error"
      })
    },
    // Get the api key permission
    getKeyPermission: function() {
      if(this.apikey) {
        var url = localStorage.getItem('websiteurl') + "/daass/extension/getKeyPermission?apiKey=" + this.apikey
        this.$http.get(url).then(response => {
          // If success
          this.temp.apiKey.isAPIUser = response.data.isApiOnly //true
          this.loadPipelines();
        }, error => {
          this.alert.status = true
          this.alert.message = "Unexpected error. Please contact Openprise"
          this.alert.color = "error"
        })
      }
    },
    getAllPanels: function () {
      //  get all the panels.
      var url = localStorage.getItem('websiteurl') + "/daass/extension/panels?apiKey=" + this.apikey
      this.$http.get(url).then(response => {
        //if success
        this.panels = response.data.data
        this.panels = this.groupBy(this.panels, 'isAdmin')
        this.panels.unshift({id:'',name:'New Panel'})
      }, error => {
        this.alert.status = true
        this.alert.message = "Error occured while fetching panels."
        this.alert.color = "error"
      })
    },
    groupBy: function (data, groupByprop) {
      // For removing headers and dividers
      data = _.reject(data, function (item) {
        if(item[groupByprop] === undefined) {
          return true
        }
      })
      data = _.orderBy(data, groupByprop, 'desc')
      let tempGroup = ''
      var groupedData = []
      _.forEach(data, function (item) {
        if(item[groupByprop] != undefined) {
          if(tempGroup != item[groupByprop].toString()) {
            groupedData.push({header: item[groupByprop] ? 'Owned by Me' : 'Shared with Me'})
            groupedData.push({divider: true})
          }
          tempGroup = item[groupByprop].toString()
        }
        groupedData.push(item)
      })
      return groupedData
    },
    getAllTemplates: function() {
      // To get all the templates.
      var url = localStorage.getItem('websiteurl') + "/daass/extension/templates?apiKey=" + this.apikey
      this.$http.get(url).then(response => {
        //if success
        this.templates = response.data.data
        this.templates = this.groupBy(this.templates, 'isAdmin')
        this.templates.unshift({id:'',name:'New Template'})
        this.getAllPanels()
      }, error => {
        this.alert.status = true
        this.alert.message = "Error occured while fetching templates."
        this.alert.color = "error"
      })
    },
    //To sort output table data
    sortedOutput: function(response) {
      return response.sort((a,b)=> {
        var modifier = 1;
        if(this.order === 'desc')
          modifier = -1;
        if(a[this.curColumn] < b[this.curColumn]){
           return -1 * modifier;
        }
        if(a[this.curColumn] > b[this.curColumn]){
          return 1 * modifier;
        }
        return 0;
      });
    },
    //To resize window
    resizeWindow: function(type) {
      localStorage.setItem('stepSize',this.stepSize);
      var minWidth=415;
      var stepWidth=parseInt(this.stepSize);
      if(stepWidth>=75 && stepWidth<=250){
        if(type=='expand'){
          var popupWidth = $('#popupTest').width();
          popupWidth= parseInt(popupWidth) + stepWidth;
          var iframeWidth = parseInt(popupWidth)+this.toggleSize;
          chrome.tabs.executeScript({
            code:"$('#opextiframe').width("+iframeWidth+");  $(window).width() "
          }, (results) => {
              if(popupWidth<results[0]){
                $('#popupTest').width(popupWidth);
              }
          });
        }
        else if(type=='shrink'){
          var popupWidth = $('#popupTest').width();
          popupWidth = parseInt(popupWidth)-stepWidth;
          if(popupWidth > minWidth){
            var iframeWidth = parseInt(popupWidth)+this.toggleSize;
            $('#popupTest').width(popupWidth);
            chrome.tabs.executeScript({
              code:"$('#opextiframe').width("+iframeWidth+");"
            }, (results) => {
          });
        }
        else{
          var iframeWidth=minWidth+this.toggleSize;
          $('#popupTest').width(minWidth);
          chrome.tabs.executeScript({
            code:"$('#opextiframe').width("+iframeWidth+");"
          }, (results) => {
        });
        }
        }
      }
    },
    //To display error message if template and panel names are duplicate
    displayAlert: function(error,type,field) {
      if(_.includes(error.errors[0].message, "must be unique")){
        this.alert.message = type+" name must be unique "
        this.dialog[field] = false
      }
      else{
        this.alert.message = error.errors[0].message
      }
    },
    //To delete Panel
    deletePanel: function(panelId) {
      var url = localStorage.getItem('websiteurl') + "/daass/extension/panels/" + panelId +"?apiKey=" + this.apikey
      this.$http.delete(url).then(response => {
        //if success
        var index = _.findIndex(this.panels, {id: panelId})
        if(index >= 0) {
          this.panels.splice(index, 1)
        }
        this.clearValues();
        this.panel = "";
        this.pipeline = "";
        this.alert.status = true
        this.alert.message = "Panel deleted successfully."
        this.alert.color = "success"
        this.dialog.deleteDialog = false
      }, error => {
        this.deleteTempPanel.panelStatus = true
        let temp = ''
        if(error.body.errors){
          // To display the template names which are associated with this panel
          _.forEach(error.body.errors.templates,function(item){
            temp = temp + item.name  + ","
          })
          let tempPanel = _.trimEnd(temp,',')
          this.deleteTempPanel.message = error.body.errors.errorMessage + ": <b>" + tempPanel + "</b> and cannot be deleted. Please remove it from the template(s)."
        }else{
          this.deleteTempPanel.message = "Error while deleting panel."
        }
      })
    },
    //To get template details
    getTemplateDetails: function(){
      if(this.template){
        this.configPanels = _.sortBy(_.result(_.find(this.templates, {id: this.template}), 'panels'),'order')
        this.accessType.template = _.result(_.find(this.templates, {id: this.template}), 'accessType')
        this.isAdmin.template = _.result(_.find(this.templates,{id:this.template}),'isAdmin')
       //To get default template
        if(this.template == localStorage.getItem('defaultTemplate')){
          this.setTemplate=true;
        }
        else{
          this.setTemplate=false;
        }
      }
      else{
        this.configPanels= [{name:'',id:''}];
      }
    },
    //To get panel details
    getPanelDetails: function() {
      this.loadPanel();
    },
    replaceDOMData: function() {
      _.forEach(this.templatePanels,function(panel) {
        if(panel.outputMapping[0].key) {
          chrome.tabs.executeScript({
            code: "window.location.hostname"
          }, (result) => {
            let hostname = result[0];
            chrome.tabs.executeScript({
              code:  replaceAPIResponseToForm(panel.outputMapping, panel.response[0], hostname)
            });
          })
        }
      });
    },
    //To sort the attributes in output response
    onSortOutput: function(temp){
      if(this.curColumn==''){
       this.curColumn=temp;
      }
      if(this.curColumn==temp){
       this.order=this.order==='asc'?'desc':'asc';
     }
      this.curColumn=temp;
    },
    //To sort the attributes in output table configuration
    onSortedOrder: function(column){
      this.sortDirection=true;
      this.order=this.order==='asc'?'desc':'asc';
      const sort = _.orderBy(this.outputTableConfig, [item=> item[column].toLowerCase()], [this.order]);
      this.outputTableConfig=sort;
   },
    //To check and uncheck attributes
    onChecked: function(){
      var len=this.outputTableConfig.length;
      if(this.outputTableConfig.length == _.filter(this.outputTableConfig, {visibility: true}).length)
        this.checkAll = true;
      else
        this.checkAll = false;
    },
    //To select all and unselect all attributes
    selectAll: function(){
      if(this.checkAll==true){
        _.forEach(this.outputTableConfig,function(value){
          value.visibility=true;
        });
      }
      else{
        _.forEach(this.outputTableConfig,function(value){
          value.visibility=false;
        });
      }
    },
    //To delete the template
    deleteTemplate: function(templateId){
      var url = localStorage.getItem('websiteurl') + "/daass/extension/templates/" + templateId +"?apiKey=" + this.apikey;
      this.$http.delete(url).then(response => {
        //if success
        var index = _.findIndex(this.templates, {id: templateId})
        if(index >= 0) {
          this.templates.splice(index, 1)
        }
        this.template=''
        this.configPanels=[{name:'',id:''}]
        this.alert.status = true
        this.alert.message = "Template deleted successfully."
        this.alert.color = "success"
      }, error => {
        this.alert.status = true
        this.alert.message = "Error while deleting template."
        this.alert.color = "error"
      })
      this.dialog.deleteDialog = false
    },
  //To validate API in settings
    validateAPIInSettings: _.debounce(function (e) {
      localStorage.setItem('websiteurl', this.url);
      if (!this.apikey) {
        this.temp.isValidAPIKey = "Required"
        return
      }
      this.loading = true;
      var url = localStorage.getItem('websiteurl') + "/daass/pipelines/getAPIEnabledPipelines?apiKey=" + this.apikey;
      this.$http.get(url).then(response => {
        this.apiEnabledPipelines = response.body.data;
        this.isErrorAPIKey = false;
        this.temp.isValidAPIKey = "";
        this.loading = false;
        localStorage.setItem('apikey', this.apikey);
      }, error => {
        this.isErrorAPIKey = true;
        this.apiEnabledPipelines = [];
        if(error.status == 404)
          this.temp.isValidAPIKey = "Invalid API URL";
        else if (error.body.error_message)
          this.temp.isValidAPIKey = error.body.error_message;
        else
          this.temp.isValidAPIKey = 'Invalid Environment'
      });
     }, 1000),
    // To clear all the configured values
    clearValues: function() {
      this.inputMapping = [{key: '', value: ''}];
      this.outputMapping = [{key: '', value: ''}];
      this.inputBindings = {};
      this.outputBindings = {};
    },
    validateAPIKey: function() {
      this.loadPipelines();
    },
    isAPIKeyAvailable: function() {
      if(localStorage.getItem('apikey') && !this.isErrorAPIKey) return true;
      return false;
    },
    // To fetch all API enabled pipelines
    loadPipelines: function() {
      if(localStorage.getItem('apikey') && !this.isErrorAPIKey) {
        this.apikey = localStorage.getItem('apikey');
      }
      if(!this.apikey) {
        this.temp.isValidAPIKey = "Required"
        return
      }
      this.loading = true;
      var url = localStorage.getItem('websiteurl') + "/daass/pipelines/getAPIEnabledPipelines?apiKey=" + this.apikey;
      this.$http.get(url).then(response => {
        this.apiEnabledPipelines = response.body.data;
        this.isErrorAPIKey = false;
        this.temp.isValidAPIKey = "";
        this.loading = false;
        localStorage.setItem('apikey', this.apikey);
        this.getAllTemplates()
      }, error => {
        this.isErrorAPIKey = true;
        this.loading = false;
        this.apiEnabledPipelines = [];
        if(error.status == 404)
          this.temp.isValidAPIKey = "Invalid API Key";
        else if (error.body.error_message)
          this.temp.isValidAPIKey = error.body.error_message;
        else
          this.temp.isValidAPIKey = 'Invalid Environment'
      });
    },
    //To load the panels details
    loadPanel: function() {
      this.run=false;
      if(this.panel) {
        this.loadingFields=true;
        let panel = _.find(this.panels, {id: this.panel})
        this.accessType.panel = panel.accessType
        this.isAdmin.panel = panel.isAdmin
        this.outputResponse = null;
        if(panel) {
          this.pipeline = panel.pipeline.id;
          this.getFieldInfo().then(function(response){
            this.inputFields = _.fromPairs(_.sortBy(_.toPairs(response.data.input[0]), function(a){return a[0]}));
            this.outputFields = _.fromPairs(_.sortBy(_.toPairs(response.data.output.data[0]), function(a){return a[0]}));
            // this.inputMapping = JSON.parse(panel.inputMapping)
            // this.outputMapping = JSON.parse(panel.outputMapping)
            if(!_.isArray(panel.inputMapping)) {
              this.inputMapping = JSON.parse(panel.inputMapping)
            }
            if(!_.isArray(panel.outputMapping)) {
              this.outputMapping = JSON.parse(panel.outputMapping)
            }
            this.errorMessage = "";
            this.errorAPI = false;
            _.map(this.inputMapping, function(item) {
              if(item.sourceId) {
                chrome.tabs.executeScript({
                  code: "if(document.getElementById('" + item.sourceId + "')) document.getElementById('" + item.sourceId + "').value" //argument here is a string but function.toString() returns function's code
                }, (results) => {
                    if(results[0])
                      item.targetValue = results[0];
                    else
                      this.errorMessage += item.sourceId + " Not Found";
                });
              }
            });
            var obj = {};
            _.map(this.outputMapping, function(item) {
              obj[item.sourceId] = item.key;
            });
            this.outputBindings = obj;
            var temp = [];
            if(!_.isArray(panel.attributes)) {
              panel.outputTable = JSON.parse(panel.attributes)
            }
            else {
              panel.outputTable = panel.attributes
            }
            // panel.outputTable = JSON.parse(panel.attributes)
            if((_.size(this.outputFields))==(_.size(panel.outputTable))){
                temp=panel.outputTable;
            }
            else{
                temp=panel.outputTable;
              _.forEach(this.outputFields, function(value,key) {
                  var attrObj = _.find(panel.outputTable, {attribute:key});
                  if(!attrObj){
                    var obj = {};
                    obj.attribute = key;
                    obj.visibility = false;
                    obj.displayLabel =key;
                    obj.edit = false;
                    temp.push(obj);
                  }
              });
            }
            this.loadingFields=false;
            this.outputTableConfig = temp;
              if(this.outputTableConfig.length == _.filter(this.outputTableConfig, {visibility: true}).length)
                this.checkAll = true;
              else
                this.checkAll = false;
            }).catch(function(response){
                this.loadingFields=false;
                this.errorAPI=true;
                if(response.data.status == 404)
                  this.errorMessage = response.data.errors;
                else
                  this.errorMessage = "Unexpected error. Please contact Openprise";
                if(response.body.errors){
                  this.errorMessage=response.body.errors;
                }
                this.temp.isValidAPIKey = this.errorMessage;
              });
            }
      }
      else {
        this.clearValues();
        this.pipeline = "";
        this.errorMessage = "";
        this.outputResponse = null;
        this.errorAPI = false;
      }
    },
    // To edit the display label inside table data
  	toggleEdit: function(index,item){
      var el = this.$refs.search[index];
    	Vue.set(item,'edit', !item.edit);
      // Focus input field
      if(item.edit){
        Vue.nextTick(function() {
          el.focus();
	  		})
      }
    },
    saveEdit: function(index,item){
     	//save your changes
      this.toggleEdit(index,item);
    },
    getRequestPayload: function(request) {
      return new Promise((resolve, reject) => {
        chrome.tabs.executeScript({code: "var request=" + request},function() {
          chrome.tabs.executeScript({
            code: '(' + function() {
              var obj = {};
              let hostname = window.location.hostname;
              for(var key in request) {
                  if(request[key].sourceId == undefined && request[key].targetValue == undefined) {
                    obj[request[key].key] = request[key].value;
                  }
                  else if(request[key].sourceId !== undefined && request[key].targetValue !== undefined && request[key].value.startsWith("<<") && request[key].value.endsWith(">>")) {
                      // Form Edit Mode
                      if(request[key].formField) {
                        // If panel is configured in Salesforce Lightning and opened in Lightning
                        if(request[key].hostname.includes('lightning.force.com') && hostname.includes('lightning.force.com')) {
                          let id = $("span:contains('" + request[key].sourceId + "')").closest('label').next().attr("id");
                          obj[request[key].key] = document.getElementById(id).value;
                        }
                        // If panel is configured in Salesforce Classic and opened in Classic
                        else if(request[key].hostname.includes('salesforce.com') && hostname.includes('salesforce.com')) {
                          obj[request[key].key] = document.getElementById(request[key].sourceId).value;
                        }
                        // If the panel is configured in Lightning and opened in Classic
                        else if(request[key].hostname.includes('salesforce.com') && hostname.includes('lightning.force.com')) {
                          let label = request[key].key;
                          let id = $("span:contains('" + label + "')").closest('label').next().attr("id");
                          obj[request[key].key] = document.getElementById(id).value;
                        }
                        // If the panel is configured in Classic and opened in Lightning
                        else if(request[key].hostname.includes('lightning.force.com') && hostname.includes('salesforce.com')) {
                          let id = $("label:contains('" + request[key].sourceId + "')").attr("for");
                          obj[request[key].key] = document.getElementById(id).value;
                        }
                      }
                      // Form View Mode
                      else {
                        if(request[key].hostname.includes('lightning.force.com') && hostname.includes('lightning.force.com')) {
                          obj[request[key].key] = $("span.test-id__field-label:contains('" + request[key].sourceId + "')").closest('div').next().find('.slds-form-element__static').text();
                        }
                        else if(request[key].hostname.includes('salesforce.com') && hostname.includes('salesforce.com')) {
                          obj[request[key].key] = $('#' + request[key].sourceId).text();
                        }
                        else if(request[key].hostname.includes('salesforce.com') && hostname.includes('lightning.force.com')) {
                          obj[request[key].key] = $("span.test-id__field-label:contains('" + request[key].key + "')").closest('div').next().find('.slds-form-element__static').text();
                        }
                        else if(request[key].hostname.includes('lightning.force.com') && hostname.includes('salesforce.com')) {
                          obj[request[key].key] = $("td:contains('" + request[key].sourceId + "')").next()[0].innerText;
                        }
                      }
                  }
                  else if(request[key].sourceId !== undefined && request[key].targetValue !== undefined && !request[key].value.startsWith("<<") && !request[key].value.endsWith(">>")) {
                    obj[request[key].key] = request[key].value;
                  }
              }
              return obj;
            } + ')()'
          },function(response) {
            resolve(response[0]);
          });
        });
      });
    },
    delay: function(p) {
      return new Promise(resolve => setTimeout(resolve, 1000));
    },
    processTemplatePanels: async function() {
      let length = _.size(this.templatePanels);
      for(i=0; i<length; i++) {
        await this.processPanelContent(this.templatePanels[i],i);
      }
    },
    processPanelContent: async function(p,index) {
      p.error = ''
      p.type = ''
      let self = this;
      if(!_.isArray(p.inputMapping)) {
        p.inputMapping = JSON.parse(p.inputMapping)
      }
      if(!_.isArray(p.outputMapping)) {
        p.outputMapping = JSON.parse(p.outputMapping)
      }
      let panel1 = _.find(self.panels, {id: p.id})
      let panel = Object.assign({},panel1)
      // if(!_.isArray(panel.inputMapping)) {
      //     panel.inputMapping = JSON.parse(panel.inputMapping)
      // }
      // if(!_.isArray(panel.outputMapping)) {
      //     panel.outputMapping = JSON.parse(panel.outputMapping)
      // }
      if(panel){
        let pipelineId = panel.pipeline.id;
        let apiKey = localStorage.getItem('apikey');
        let url = localStorage.getItem('websiteurl') + "/daass/pipelines/" + pipelineId + "/processRecords?apiKey=" + apiKey;
        self.$set(p, 'executing', true);
        await this.delay(p);
        self.getRequestPayload(panel.inputMapping).then(function(payload) {
          if(payload['error']) {
            p.executing = false;
            p.type = "error";
            p.error = payload['error'];
          }
          else if(!_.isEmpty(_.compact(_.values(payload)))) {
            self.$http.post(url,[payload]).then(
              // Success block
              function(response){
                if(response.data.success) {
                  p.executing = false
                  if(response.data.data.length == 0) {
                    p.type = "info";
                    p.error = "No Data Found";
                  }
                  else {
                    self.panelCounter = self.panelCounter - 1;
                    p.replaceFields = panel.response;
                    p.response = response.data.data;
                    if(!_.isArray(panel.attributes)) {
                      panel.attributes = JSON.parse(panel.attributes)
                    }
                    // p.outputColumns = {}
                    this.$set(p, 'outputColumns', _.filter(panel.attributes, {visibility: true}))
                  }
                }
                else {
                  p.executing = false;
                  p.type = "error";
                  p.error = response.data.error_message;
                }
              },
              // Error block
              function(response) {
                p.executing = false;
                p.type = "error";
                if(response.data.error_message)
                  p.error = response.data.error_message;
                else
                  p.error = response.body.errors;
              });
          }
          else {
            p.executing = false;
            p.type = "warning";
            p.error = "No input data found.";
          }
        },function(response) {
        });
    }
    else{
      p.type="error";
      p.error="Job has deleted";
    }
    },
    //To execute the selected template
    runTemplate: function() {
      this.run=true;
      if(this.templateRun)
        this.templatePanels = _.sortBy(_.result(_.find(this.templates, {id: this.templateRun}),'panels'),'order');
      else
        return alert("Please select template to run");
      this.collapsiblePanels = _.map(this.templatePanels, function() {return true});
      this.panelCounter = _.size(this.templatePanels);
      this.processTemplatePanels(this.templatePanels);
    },
    // Get the pipeline information input, output fields
    getFieldsInfo: function() {
        this.clearValues();
        this.checkAll=false;
        this.loading = true;
        this.sortDirection=false;
        this.executing=false;
        this.errorAPI=false;
        this.getFieldInfo().then(function(response){
            this.loading = false;
            var temp = [];
            this.inputFields = _.fromPairs(_.sortBy(_.toPairs(response.data.input[0]), function(a){return a[0]}));
            this.outputFields = _.fromPairs(_.sortBy(_.toPairs(response.data.output.data[0]), function(a){return a[0]}));
            _.forEach(this.outputFields, function(value, key) {
              var obj = {};
              obj.attribute = key;
              obj.visibility = false;
              obj.displayLabel = key;
              obj.edit = false;
              temp.push(obj);
            });
            this.outputTableConfig = temp;
            this.isErrorAPIKey = false;
            this.errorMessage = "";
        })
        .catch(function(error){
            this.loading = false;
            this.inputFields = [];
            this.outputFields = [];
            this.isErrorAPIKey = true;
            if(error.status == 404)
              this.errorMessage = "Invalid API URL";
            else
              this.errorMessage = error.body.error_message;
            this.temp.isValidAPIKey = this.errorMessage;
        });
    },
    // TO get the input, output fields information of the pipeline
    getFieldInfo: function() {
      var pipelineId = this.pipeline;
      var apiKey = localStorage.getItem('apikey');
      var url = localStorage.getItem('websiteurl') + "/daass/pipelines/" + pipelineId + "/getSample?apiKey=" + apiKey;
      return this.$http.get(url, function(response, status, request) {
        if (request.status == 200) {
            this.errorAPI=false;
            resolve(request.response);
         } else {
            this.errorAPI = true;
            reject(Error(request.statusText));
         }
     });
    },
    editPanelName:  function (panelId) {
      this.dialog.editPanelDialog = true
      this.dialogTextField.editPanel = _.result(_.find(this.panels, {id: panelId}), 'name')
    },
    // To configure and save panel
    savePanel: function() {
      if(this.panel == '') {
        // New panel
        if(!this.$refs.newPanelName.validate())
          return;
        var url = localStorage.getItem('websiteurl') + "/daass/extension/panels?apiKey=" + this.apikey;
        var data = {
                      'name': this.dialogTextField.newPanel,
                      'pipeline': this.pipeline,
                      'accessType': this.accessType.panel,
                      'inputMapping': JSON.stringify(this.inputMapping),
                      'outputMapping': JSON.stringify(this.outputMapping),
                      'attributes': JSON.stringify(this.outputTableConfig),
                      'status': 'Active'
                   }
        this.$http.post(url, data).then(response => {
          //if success
          this.isAdmin.panel = response.data.isAdmin
          this.panel = response.data.id
          this.panels.push(response.data)
          this.panels = this.groupBy(this.panels, 'isAdmin')
          this.panels.unshift({id:'',name:'New Panel'})
          this.alert.status = true
          this.alert.message = "Panel saved successfully."
          this.alert.color = "success"
        }, error => {
          this.alert.status = true
          this.alert.color = "error"
          if(error.body && error.body.errors.length) {
            this.displayAlert(error.body,"Panel","panelDialog")
          }else {
            this.alert.message = "Error while saving Panel."
          }
        })
      }
      // Existing panel
      else {
        // var panelsObj = JSON.parse(localStorage.getItem("panels"));
        var data1 = _.find(this.panels, {id: this.panel})
        var data = Object.assign({},data1)
        if(data.name == this.dialogTextField.editPanel) {
          this.dialog.editPanelDialog = false
          this.dialogTextField.editPanel = ''
          return
        }
        if(this.dialogTextField.editPanel) {
          data.name = this.dialogTextField.editPanel
        }else {
          data.pipeline = this.pipeline
          data.accessType = this.accessType.panel
          data.inputMapping = JSON.stringify(this.inputMapping)
          data.outputMapping = JSON.stringify(this.outputMapping)
          data.attributes = JSON.stringify(this.outputTableConfig)
        }
        var url = localStorage.getItem('websiteurl') + "/daass/extension/panels/" + this.panel +"?apiKey=" + this.apikey;
        this.$http.put(url, data).then(response => {
          //if success
          var index = _.findIndex(this.panels, {id: response.data.id})
          if(this.dialogTextField.editPanel) {
            this.$set(this.panels[index], 'name', response.data.name)
          } else {
            this.$set(this.panels[index],'inputMapping',response.data.inputMapping)
            this.$set(this.panels[index],'outputMapping',response.data.outputMapping)
            this.$set(this.panels[index],'attributes',response.data.attributes)
          }
          this.dialog.editPanelDialog = false
          this.dialogTextField.editPanel = ''
          this.alert.status = true
          this.alert.message = "Panel updated successfully."
          this.alert.color = "success"
        }, error => {
          this.alert.status = true
          this.alert.color = "error"
          if(error.body && error.body.errors.length) {
            this.displayAlert(error.body,"Panel","editPanelDialog")
          }else {
            this.alert.message = "Error while updating panel."
          }
        })
      }
      this.dialog.panelDialog=false;
      this.dialogTextField.newPanel="";
    },
    editTemplateName:  function (tempId) {
      this.dialog.editTempDialog = true
      this.dialogTextField.editTemplate = _.result(_.find(this.templates, {id: tempId}), 'name')
    },
    // To save template
    saveTemplate: function() {
      _.forEach(this.configPanels, function (item, index) {
        item.order = index
      })
      // New template
      if(!this.template) {
        if(!this.$refs.newTemplateName.validate()) {
          return
        }
        var templName = this.dialogTextField.newTemplate
        if(templName) {
          var url = localStorage.getItem('websiteurl') + "/daass/extension/templates?apiKey=" + this.apikey;
          var data = {
                        'name': templName,
                        'panels': this.configPanels,
                        'accessType': this.accessType.template,
                        'status': 'Active'
                     }
          this.$http.post(url, data).then(response => {
            //if success
            this.isAdmin.template = response.data.isAdmin
            this.templates.push(response.data)
            this.template = response.data.id
            this.templates = this.groupBy(this.templates, 'isAdmin')
            this.templates.unshift({id:'',name:'New Template'})
            this.alert.status = true
            this.alert.message = "Template saved successfully."
            this.alert.color = "success"
          }, error => {
            this.alert.status = true
            this.alert.color = "error"
            if(error.body && error.body.errors.length) {
              this.displayAlert(error.body,"Template","saveTempDialog")
            }
            else {
              this.alert.message = "Error while saving template"
            }
          })
        }
      }
      // Existing template
      else {
          var data1 = _.find(this.templates, {id: this.template})
          var data = Object.assign({},data1)
          if(this.setTemplate){
            localStorage.setItem('defaultTemplate',this.template);
            this.templateRun = this.template;
          }
          else{
            localStorage.setItem('defaultTemplate',"");
            this.templateRun = "";
          }
          // while updating name
          if(data.name == this.dialogTextField.editTemplate) {
            this.dialog.editTempDialog = false
            this.dialogTextField.editTemplate = ''
            return
          }
          // while updating panels in templates
          if(this.dialogTextField.editTemplate) {
            data.name = this.dialogTextField.editTemplate
          }else {
            data.panels = this.configPanels
            data.accessType = this.accessType.template
          }
          var url = localStorage.getItem('websiteurl') + "/daass/extension/templates/" + this.template +"?apiKey=" + this.apikey;
          this.$http.put(url, data).then(response => {
            //if success
            var index = _.findIndex(this.templates, {id: response.data.id})
            if(this.dialogTextField.editTemplate) {
              this.$set(this.templates[index], 'name', response.data.name)
            } else {
              this.$set(this.templates[index], 'panels', response.data.panels)
              this.$set(this.templates[index], 'accessType', response.data.accessType)
            }
            this.dialog.editTempDialog = false
            this.dialogTextField.editTemplate = ''
            this.alert.status = true
            this.alert.message = "Template updated successfully."
            this.alert.color = "success"
          }, error => {
            this.alert.status = true
            this.alert.color = "error"
            if(error.body && error.body.errors.length) {
              this.displayAlert(error.body,"Template","editTempDialog")
            } else {
              this.alert.message = "Error while updating template."
            }
          })
        }
      this.dialog.saveTempDialog=false;
      this.dialogTextField.newTemplate="";
    },
    // Called upon when clicking on the execute button
    executeAction: function() {
      var obj = {};
      if(this.pipeline == '') {
        alert("Please select service");
        return;
      }

      chrome.tabs.executeScript({
        code: "window.location.hostname" // Get the hostname
      }, (result) => {
        let hostname = result[0];
        this.executing = true;
        var promise = [];
        _.forEach(this.inputMapping, function(item) {
            var test = new Promise(function(resolve, reject) {
              if(item.sourceId == undefined && item.targetValue == undefined) {
                obj[item.key] = item.value;
                resolve(obj);
              }
              else if(item.sourceId !== undefined && item.targetValue !== undefined && _.startsWith(item.value, "<<") && _.endsWith(item.value, ">>")) {
                if(item.formField) {
                  // If panel is configured in Salesforce Classic and opened in Classic
                  if(hostname.includes('salesforce.com') && item.hostname.includes('salesforce.com')) {
                    chrome.tabs.executeScript({
                      code: "$('#" + item.sourceId + "').val()"
                    }, (result) => {
                      obj[item.key] = result[0];
                      resolve(obj);
                    });
                  }
                  // If panel is configured in Salesforce Lightning and opened in Lightning
                  else if(hostname.includes('lightning.force.com') && item.hostname.includes('lightning.force.com')) {
                    chrome.tabs.executeScript({
                      code: "document.getElementById($(\"span:contains('" + item.sourceId + "')\").closest('label').next().attr('id')).value"
                    }, (result) => {
                      obj[item.key] = result[0];
                      resolve(obj);
                    });
                  }
                  // If panel is configured in Salesforce Lightning and opened in Classic
                  else if(hostname.includes('salesforce.com') && item.hostname.includes('lightning.force.com')) {
                    chrome.tabs.executeScript({
                      code: "$('#'+$(\"label:contains('" + item.sourceId + "')\").attr('for')).val()"
                    }, (result) => {
                      obj[item.key] = result[0];
                      resolve(obj);
                    });
                  }
                  // If panel is configured in Salesforce Classic and opened in Lightning
                  else if(hostname.includes('lightning.force.com') && item.hostname.includes('salesforce.com')) {
                    chrome.tabs.executeScript({
                      code: "document.getElementById($(\"span:contains('" + item.key + "')\").closest('label').next().attr('id')).value"
                    }, (result) => {
                      obj[item.key] = result[0];
                      resolve(obj);
                    });
                  }
                }
                // If it is not form field
                else {
                  if(hostname.includes('salesforce.com')) {
                    chrome.tabs.executeScript({
                      code: "document.getElementById('" + item.sourceId + "').innerText"
                    }, (result) => {
                      obj[item.key] = result[0];
                      resolve(obj);
                    });
                  }
                  else if(hostname.includes('lightning.force.com')) {
                    chrome.tabs.executeScript({
                      code: "$(\"span.test-id__field-label:contains('" + item.sourceId + "')\").closest('div').next().find('.slds-form-element__static').text()"
                    }, (result) => {
                      obj[item.key] = result[0];
                      resolve(obj);
                    });
                  }
                }
              }
              else {
                obj[item.key] = item.value;
                resolve(obj);
              }
            });
            promise.push(test);
        });
        Promise.all(promise).then(function(values) {
          vueObj.processRecords(values[0],hostname);
        });
      });
    },
    // To process the pipeline and fetch the respective records
    processRecords: function(obj,hostname) {
      var pipelineId = this.pipeline;
      var apiKey = this.apikey;
      var template = null;
      if(pipelineId) {
        var url = localStorage.getItem('websiteurl') + "/daass/pipelines/" + pipelineId + "/processRecords?apiKey=" + apiKey;
        this.$http.post(url, [obj]).then(function(response) {
          if(response.data.success) {
            this.executing = false;
            if(this.template)
              template = JSON.parse(localStorage.getItem(this.template));
            if(template && template.outputTable) {
              this.outputResponse = response.data.data;
              this.outputColumns = _.filter(template.outputTable, {visibility: true});
              var temp = [];
              _.forEach(this.outputColumns, function(attr) {
                  var obj = {};
                  obj.attribute = attr.attribute;
                  obj.visibility = attr.visibility;
                  obj.displayLabel = attr.displayLabel;
                  obj.edit = attr.edit;
                  temp.push(obj);
              });
              temp=this.outputTable;
            _.forEach(this.outputFields, function(value, key) {
                var colObj = _.find(template.outputTable, {attribute: key});
                var obj = {};
                if(!colObj) {
                  obj.attribute = key;
                  obj.visibility = false;
                  obj.displayLabel = key;
                  obj.edit = false;
                  temp.push(obj);
                }
              });
            this.outputTableConfig = temp;
              if(this.outputMapping[0].key) {
                chrome.tabs.executeScript({
                  code:  replaceResponseToForm(response.data.data[0],hostname)
                });
              }
            }
            else {
              chrome.tabs.executeScript({
                code:  replaceResponseToForm(response.data.data[0],hostname)
              });
            }
          }
          else {
            this.errorMessage = response.data.error_message;
          }
        }, function(response) {
        });
      }
    },
    // To add one more input or output fields
    addOneMore: function(type) {
      if(type == 'input')
        this.inputMapping.push({key: '', value: ''});
      else if(type=='output')
        this.outputMapping.push({key: '', value: ''});
      else
          if(this.configPanels.length<5)
            this.configPanels.push({name:'',id:''});
          else
            alert("You can add up to 5 Panels only.");

    },
    // To remove the current row
    removeCurrent: function(index, type) {
      if(type == 'input')
        this.inputMapping.splice(index-1, 1);
      else if(type=='output')
        this.outputMapping.splice(index-1, 1);
      else
        this.configPanels.splice(index,1);
    },
    // Converts the template to hyphenize
    getKebabCase: function(str,item,i) {
      return str + _.kebabCase(item) + i;
    },
    // To bind the external form with input fields
    bindInputs: function(id, index, type) {
      if(($("#" + type + _.kebabCase(id)+index)).hasClass('active')){
        $("#" + type + _.kebabCase(id)+index).removeClass("active");
      }
      else{
        $(".active").removeClass("active");
        $("#" + type + _.kebabCase(id)+index).addClass("active");
      }
    },
    // To bind the external form with output fields
    bindOutputFields: function(outputKey) {
      let obj = [];
      _.map(this.outputMapping, function(item) {
        if(item.sourceId)
          obj[item.sourceId] = item.key;
      });
      this.outputBindings = obj;
      // Find and delete if key is already existing in output bindings
      var outputBindings = JSON.parse(JSON.stringify(this.outputBindings));
      _.forEach(outputBindings, function(key,value) {
        if(key == outputKey && vueObj.outputBindings)
          delete vueObj.outputBindings[value];
      })
    },
    // Toggle the popup form when clicking on OP icon
    togglePopup: function() {
      this.toggle= !this.toggle;
      var minWidth = document.getElementById("popupTest").style.width;
      if(!minWidth){
        document.getElementById("popupTest").style.width='415px';
      }
      if(this.toggle){
        chrome.tabs.executeScript({
          code: "document.getElementById('opextiframe').style.right = '-" + document.getElementById("popupTest").style.width + "'"
          }, (results) => {
        });
      }
      else{
        chrome.tabs.executeScript({
          code: "document.getElementById('opextiframe').style.right = '0';"
        }, (results) => {
        });
      }
    },
    // Closes the extention when clicking on close button
    closeOPExtFrame: function() {
      chrome.tabs.executeScript({
        code: "document.getElementById('opextiframe').remove()"
      }, (results) => {
      });
    },
    // Need to validate form before submit
    validateBeforeSubmit: function() {
    }
  }
});

  // Get element data from form
  function getAttrValue(item) {
    let str;
    if(!item.formField) {
      str = "$(\"span.test-id__field-label:contains('" + item.sourceId + "')\").closest('div').next().find('.slds-form-element__static').text()"
    }
    else {
      str = "$(\"span:contains('" + item.sourceId + "')\").closest('label').prev().siblings().html()"
    }
    return str;
  }

  // Replace the API response to form
  function replaceResponseToForm(response,hostname) {
    var str = '';
    if(response) {
      for(var i=0; i<_.keys(vueObj.outputBindings).length; i++) {
        if(response[_.values(vueObj.outputBindings)[i]]) {
          let outputMappingIndex = _.findIndex(vueObj.outputMapping, {sourceId: _.keys(vueObj.outputBindings)[i]});
          // If the panel is configured in Salesforce Lightning and opened in Lightning
          if(vueObj.outputMapping[outputMappingIndex].hostname.includes('lightning.force.com') && hostname.includes('lightning.force.com')) {
            if(response[_.values(vueObj.outputBindings)[i]]) {
              chrome.tabs.executeScript({
                code: "document.getElementById($(\"span:contains('" + _.keys(vueObj.outputBindings)[i] + "')\").closest('label').next().attr('id')).value='" + response[_.values(vueObj.outputBindings)[i]] + "'"
              }, (result) => {
              });
            }
          }
          // If the panel is configured in Salesforce Classic and opened in Classic
          else if(vueObj.outputMapping[outputMappingIndex].hostname.includes('salesforce.com') && hostname.includes('salesforce.com')) {
            if(response[_.values(vueObj.outputBindings)[i]]) {
              str = str + "document.getElementById('" + _.keys(vueObj.outputBindings)[i] + "').value=\"" + response[_.values(vueObj.outputBindings)[i]] + "\";";
            }
          }
          else if(vueObj.outputMapping[outputMappingIndex].hostname.includes('lightning.force.com') && hostname.includes('salesforce.com')) {
            if(response[_.values(vueObj.outputBindings)[i]]) {
              chrome.tabs.executeScript({
                code: "$('#'+$(\"label:contains('" + _.keys(vueObj.outputBindings)[i] + "')\").attr('for')).val('" + response[_.values(vueObj.outputBindings)[i]] + "')"
              }, (result) => {
              });
            }
          }
          // If the panel is configured in Salesforce Classic and opened in Lightning
          else if(vueObj.outputMapping[outputMappingIndex].hostname.includes('salesforce.com') && hostname.includes('lightning.force.com')) {
            let label = _.find(vueObj.outputMapping,{sourceId: _.keys(vueObj.outputBindings)[i]}).value;
            label = label.substring(2,label.length-2);
            if(response[_.values(vueObj.outputBindings)[i]]) {
              chrome.tabs.executeScript({
                code: "document.getElementById($(\"span:contains('" +  label + "')\").closest('label').next().attr('id')).value='" + response[_.values(vueObj.outputBindings)[i]] + "'"
              }, (result) => {
              });
            }
          }
        }
      }
    }
    return str;
  }

  // Replaces API response into form
  function replaceAPIResponseToForm(outputMappings, response, hostname) {
    var str = '';
    for(var i=0; i< outputMappings.length; i++) {
      // If the panel is configured in Salesforce Lightning and opened in Salesforce Lightning
      if(hostname.includes('lightning.force.com') && outputMappings[i].hostname.includes('lightning.force.com')) {
        if(response[outputMappings[i].key]) {
          chrome.tabs.executeScript({
            code: "document.getElementById($(\"span:contains('" + outputMappings[i].sourceId + "')\").closest('label').next().attr('id')).value='" + response[outputMappings[i].key] + "'"
          }, (result) => {
          });
        }
      }
      // If the panel is configured in Salesforce Classic and opened in Salesforce Classic
      else if(hostname.includes('salesforce.com') && outputMappings[i].hostname.includes('salesforce.com'))  {
        if(response[outputMappings[i].key])
          str = str + "document.getElementById('" + outputMappings[i].sourceId + "').value=\"" + response[outputMappings[i].key] + "\";";
      }
      // If the panel is configured in Salesforce Classic and opened in Salesforce Lightning
      else if(hostname.includes('lightning.force.com') && outputMappings[i].hostname.includes('salesforce.com'))  {
        let str = outputMappings[i].value;
        let label = outputMappings[i].value.substring(2,str.length-2);
        if(response[outputMappings[i].key]) {
          chrome.tabs.executeScript({
            code: "document.getElementById($(\"span:contains('" + label + "')\").closest('label').next().attr('id')).value='" + response[outputMappings[i].key] + "'"
          }, (result) => {
          });
        }
      }
      // If the panel is configured in Salesforce Lightning and opened in Salesforce Classic
      else if(hostname.includes('salesforce.com') && outputMappings[i].hostname.includes('lightning.force.com'))  {
        if(response[outputMappings[i].key]) {
          chrome.tabs.executeScript({
            code: "document.getElementById($(\"label:contains('" + outputMappings[i].sourceId + "')\").attr('for')).value='" + response[outputMappings[i].key] + "'"
          }, (result) => {
          });
        }
      }
    }
    return str;
  }

  chrome.runtime.onMessage.addListener(
    function(message, sender, sendResponse) {
        switch(message.type) {
            case "DOMInfo":
                if($(".active").length > 0 && message.targetId !== '') {
                  var activeEleId = $(".active")[0].id;
                  var activeEleKey = $(".active").attr('attrkey');
                  var activeEleStatus = _.startsWith(activeEleId, 'input');
                  var activeEleIndex = _.findIndex(activeEleStatus ? vueObj.inputMapping : vueObj.outputMapping, {key: activeEleKey});
                  if(activeEleStatus) {
                    vueObj.inputMapping[activeEleIndex].hostname = message.hostname;
                    vueObj.inputMapping[activeEleIndex].formField = message.formField;
                    vueObj.inputMapping[activeEleIndex].sourceId = message.targetId;
                    vueObj.inputMapping[activeEleIndex].targetValue = message.targetValue;
                    if(message.targetId)
                      vueObj.inputMapping[activeEleIndex].value = "<<" + message.targetLabel + ">>";
                    else
                      vueObj.inputMapping[activeEleIndex].value = message.targetValue;

                    // Find and delete if key is already existing in output bindings
                    _.forEach(vueObj.inputBindings, function(key,value) {
                      if(key == activeEleId)
                        delete vueObj.inputBindings[value];
                    })
                    vueObj.inputBindings[message.targetId] = activeEleId;
                  }
                  else {
                    vueObj.outputMapping[activeEleIndex].hostname = message.hostname;
                    vueObj.outputMapping[activeEleIndex].formField = message.formField;
                    vueObj.outputMapping[activeEleIndex].sourceId = message.targetId;
                    vueObj.outputMapping[activeEleIndex].targetValue = message.targetValue;
                    if(message.targetLabel)
                      vueObj.outputMapping[activeEleIndex].value ="<<" + message.targetLabel + ">>";

                    // Find and delete if key is already existing in output bindings
                    _.forEach(vueObj.outputBindings, function(key,value) {
                      if(key == activeEleKey)
                        delete vueObj.outputBindings[value];
                    })
                    $("#"+activeEleId).focus();
                    vueObj.outputBindings[message.targetId] = activeEleKey;
                  }
                }
                sendResponse(message.target);
                break;
            default:
                console.error("Unrecognised message: ", message);
        }
    }
);
